# LavaLust Product Manager

Laboratory Exercise No. 5: an authenticated CRUD application built with LavaLust 4.6, Aiven MySQL, and Render.

## Features

- Session-based login with route middleware
- Create, list, edit, and delete products
- Server-side validation, output escaping, and CSRF protection
- Aiven MySQL TLS support
- Docker and Render Blueprint deployment configuration

## 1. Create the Aiven table

Create or open an Aiven MySQL service, then run `database/schema.sql` in its Query Editor. Download the service CA certificate for verified TLS.

## 2. Configure the application

Copy `.env.example` to `.env` and enter your values. Never commit `.env`.

```dotenv
APP_ENV=development
APP_URL=https://ramirez-bonjoshpaolo-lavalust-od8y.onrender.com
APP_KEY=replace-with-a-long-random-value
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin123
DB_HOST=your-aiven-host
DB_PORT=your-aiven-port
DB_USER=avnadmin
DB_PASSWORD=your-aiven-password
DB_NAME=defaultdb
DB_SSL_CA=C:/full/path/to/ca.pem
```

For production, prefer a password hash instead of `ADMIN_PASSWORD`:

```bash
php -r "echo password_hash('your-strong-password', PASSWORD_DEFAULT), PHP_EOL;"
```

Put the result in `ADMIN_PASSWORD_HASH` and leave `ADMIN_PASSWORD` unset.

## 3. Run locally

```bash
php lava serve 3000
```

For local development, open `http://localhost:3000`. The configured login is `admin` / `admin123`.

The active Render service URL is `https://ramirez-bonjoshpaolo-lavalust-od8y.onrender.com`.

Or use Docker:

```bash
docker build -t lavalust-products .
docker run --rm -p 10000:10000 --env-file .env lavalust-products
```

## 4. Deploy to Render

1. Push this project to a new GitHub repository.
2. In Render, create a Blueprint from the repository. Render reads `render.yaml`.
3. Enter every environment variable marked `sync: false`.
4. Add the Aiven CA certificate as a Render secret file at `/etc/secrets/ca.pem`, then set `DB_SSL_CA=/etc/secrets/ca.pem`.
5. Deploy, check `/health`, sign in, and test all CRUD operations.

## Test checklist

- Product routes redirect signed-out users to `/login`.
- A signed-in user can add, view, edit, and delete products.
- Product records appear in the Aiven `products` table.
- The deployed app works through the Render HTTPS URL.

## Submission checklist

- GitHub repository URL
- Render application URL
- Screenshots: login, product list, add, edit, and delete
- Screenshot of the Aiven `products` table
- Working CRUD application
