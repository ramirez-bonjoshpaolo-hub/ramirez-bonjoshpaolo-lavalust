<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class ProductController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->call->database();
        $this->call->model('ProductModel');
    }

    public function index()
    {
        $this->call->view('products/index', array_merge($this->sharedData(), ['page_title' => 'Products', 'products' => $this->ProductModel->newestFirst()]));
    }

    public function create() { $this->renderForm('create', $this->emptyProduct(), []); }

    public function store()
    {
        $product = $this->productInput();
        $errors = $this->validateProduct($product);
        if ($errors) { $this->renderForm('create', $product, $errors); return; }
        $this->ProductModel->insert($product);
        $_SESSION['flash_success'] = 'Product added successfully.';
        redirect('products');
    }

    public function edit($id) { $this->renderForm('edit', $this->findProductOr404((int) $id), []); }

    public function update($id)
    {
        $id = (int) $id;
        $this->findProductOr404($id);
        $product = $this->productInput();
        $product['id'] = $id;
        $errors = $this->validateProduct($product);
        if ($errors) { $this->renderForm('edit', $product, $errors); return; }
        unset($product['id']);
        $this->ProductModel->update($id, $product);
        $_SESSION['flash_success'] = 'Product updated successfully.';
        redirect('products');
    }

    public function confirmDelete($id)
    {
        $this->call->view('products/delete_confirm', array_merge($this->sharedData(), ['page_title' => 'Delete product', 'product' => $this->findProductOr404((int) $id)]));
    }

    public function destroy($id)
    {
        $id = (int) $id;
        $product = $this->findProductOr404($id);
        $this->ProductModel->delete($id);
        $_SESSION['flash_success'] = 'Product “' . $product['product_name'] . '” was deleted.';
        redirect('products');
    }

    private function renderForm(string $mode, array $product, array $errors): void
    {
        $this->call->view('products/form', array_merge($this->sharedData(), ['page_title' => $mode === 'create' ? 'Add product' : 'Edit product', 'mode' => $mode, 'product' => $product, 'errors' => $errors]));
    }

    private function productInput(): array
    {
        return ['product_name' => trim((string) $this->request->post('product_name', '')), 'description' => trim((string) $this->request->post('description', '')), 'price' => trim((string) $this->request->post('price', '')), 'quantity' => trim((string) $this->request->post('quantity', ''))];
    }

    private function validateProduct(array $product): array
    {
        $errors = [];
        if ($product['product_name'] === '') $errors['product_name'] = 'Product name is required.';
        elseif (strlen($product['product_name']) > 100) $errors['product_name'] = 'Product name must be 100 characters or fewer.';
        if ($product['price'] === '' || !is_numeric($product['price']) || (float) $product['price'] < 0) $errors['price'] = 'Enter a valid price of 0 or more.';
        elseif (round((float) $product['price'], 2) > 99999999.99) $errors['price'] = 'Price exceeds the DECIMAL(10,2) limit.';
        if ($product['quantity'] === '' || filter_var($product['quantity'], FILTER_VALIDATE_INT) === false || (int) $product['quantity'] < 0) $errors['quantity'] = 'Enter a whole-number quantity of 0 or more.';
        return $errors;
    }

    private function findProductOr404(int $id): array
    {
        $product = $this->ProductModel->find($id);
        if (!$product) { show_404(); exit; }
        return $product;
    }

    private function emptyProduct(): array { return ['product_name' => '', 'description' => '', 'price' => '', 'quantity' => '']; }

    private function sharedData(): array
    {
        $success = $_SESSION['flash_success'] ?? null;
        $error = $_SESSION['flash_error'] ?? null;
        unset($_SESSION['flash_success'], $_SESSION['flash_error']);
        return ['current_user' => $_SESSION['authenticated_user']['username'] ?? '', 'flash_success' => is_string($success) ? $success : null, 'flash_error' => is_string($error) ? $error : null];
    }
}
