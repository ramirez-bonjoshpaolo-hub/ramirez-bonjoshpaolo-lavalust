<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class AuthController extends Controller
{
    public function loginForm()
    {
        $error = $_SESSION['flash_error'] ?? null;
        $success = $_SESSION['flash_success'] ?? null;
        unset($_SESSION['flash_error'], $_SESSION['flash_success']);
        $this->call->view('auth/login', ['page_title' => 'Sign in', 'error' => $error, 'flash_success' => $success, 'old_username' => '']);
    }

    public function login()
    {
        $username = trim((string) $this->request->post('username', ''));
        $password = (string) $this->request->post('password', '');
        $expectedUsername = 'admin';
        $passwordMatches = hash_equals('admin123', $password);

        if (!hash_equals($expectedUsername, $username) || !$passwordMatches) {
            usleep(250000);
            $this->call->view('auth/login', ['page_title' => 'Sign in', 'error' => 'The username or password is incorrect.', 'flash_success' => null, 'old_username' => $username]);
            return;
        }

        session_regenerate_id(true);
        $_SESSION['authenticated_user'] = ['username' => $expectedUsername, 'signed_in_at' => time()];
        $destination = $_SESSION['intended_url'] ?? '/products';
        unset($_SESSION['intended_url']);
        $_SESSION['flash_success'] = 'Welcome back. You are now signed in.';
        if (!is_string($destination) || !str_starts_with($destination, '/products')) $destination = '/products';
        redirect($destination);
    }

    public function logout()
    {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['flash_success'] = 'You have been signed out.';
        redirect('login');
    }
}
