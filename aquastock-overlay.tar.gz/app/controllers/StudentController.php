<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class StudentController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->call->library('session');
    }

    private function student_data()
    {
        return [
            'student_id' => getenv('STUDENT_ID') ?: 'Add your student ID in .env',
            'name' => getenv('STUDENT_NAME') ?: 'Bon Josh Paolo Ramirez',
            'course' => getenv('STUDENT_COURSE') ?: 'BS Information Technology',
            'year_level' => getenv('STUDENT_YEAR_LEVEL') ?: '3rd Year',
            'section' => getenv('STUDENT_SECTION') ?: 'Add your section in .env',
            'email' => getenv('STUDENT_EMAIL') ?: 'Add your school email in .env',
        ];
    }

    public function index()
    {
        $this->session->set_userdata('student_access', true);

        $this->call->view('student/index', [
            'student' => $this->student_data(),
            'title' => 'Ramirez Field Notes',
            'notice' => $this->session->flashdata('student_access_message'),
        ]);
    }

    public function profile()
    {
        $this->call->view('student/profile', [
            'student' => $this->student_data(),
            'title' => 'Bon Josh Paolo Ramirez | Student Profile',
        ]);
    }
}
