<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class Welcome extends Controller {
	public function index() {
		redirect(isset($_SESSION['authenticated_user']) ? 'products' : 'login');
	}

	public function health() {
		header('Content-Type: application/json; charset=UTF-8');
		echo json_encode(['status' => 'ok', 'application' => 'LavaLust Product Manager']);
	}
}
?>
