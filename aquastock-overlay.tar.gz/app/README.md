# LavaLust application directory

Application controllers, models, middleware, configuration, and views for the authenticated product manager.
