<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class GuestMiddleware
{
    public function handle(Closure $next)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (isset($_SESSION['authenticated_user'])) {
            redirect('products');
            exit;
        }
        return $next();
    }
}
