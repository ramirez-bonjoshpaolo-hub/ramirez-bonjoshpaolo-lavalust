<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');

class AuthMiddleware
{
    public function handle(Closure $next)
    {
        if (session_status() !== PHP_SESSION_ACTIVE) session_start();
        if (!isset($_SESSION['authenticated_user'])) {
            $_SESSION['intended_url'] = $_SERVER['REQUEST_URI'] ?? '/products';
            $_SESSION['flash_error'] = 'Please sign in to manage products.';
            redirect('login');
            exit;
        }
        return $next();
    }
}
