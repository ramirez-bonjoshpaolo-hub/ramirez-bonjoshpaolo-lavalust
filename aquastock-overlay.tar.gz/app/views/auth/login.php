<?php $current_user = ''; require APP_DIR . 'views/partials/header.php'; ?>
<section class="auth-layout">
    <aside class="auth-context" aria-label="About this application">
        <span class="eyebrow">Your inventory current</span>
        <h1>Keep every product in flow.</h1>
        <p>A calm, secure workspace for tracking prices, quantities, and product details.</p>
    </aside>
    <div class="card auth-card"><span class="eyebrow">Secure access</span><h2>Dive back in</h2><p class="muted">Sign in to continue to your product dashboard.</p><?php if (!empty($error)): ?><div class="alert alert-error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?><form method="post" action="<?= htmlspecialchars(site_url('login'), ENT_QUOTES, 'UTF-8') ?>" class="stack-form"><?php csrf_field(); ?><label>Username<input type="text" name="username" value="<?= htmlspecialchars($old_username ?? '', ENT_QUOTES, 'UTF-8') ?>" autocomplete="username" required autofocus></label><label>Password<input type="password" name="password" autocomplete="current-password" required></label><button class="button button-primary button-wide" type="submit">Enter workspace</button></form></div>
</section>
<?php require APP_DIR . 'views/partials/footer.php'; ?>
