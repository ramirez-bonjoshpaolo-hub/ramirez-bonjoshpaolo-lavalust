<?php $current_user = ''; require APP_DIR . 'views/partials/header.php'; ?>
<section class="auth-layout">
    <aside class="auth-context" aria-label="About this application">
        <span class="eyebrow">Laboratory Exercise No. 5</span>
        <h1>Product Management System</h1>
        <p>Create, view, update, and delete product records stored in Aiven MySQL.</p>
    </aside>
    <div class="card auth-card"><span class="eyebrow">Authorized users only</span><h2>Welcome back</h2><p class="muted">Sign in to manage the product inventory.</p><?php if (!empty($error)): ?><div class="alert alert-error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?><form method="post" action="<?= htmlspecialchars(site_url('login'), ENT_QUOTES, 'UTF-8') ?>" class="stack-form"><?php csrf_field(); ?><label>Username<input type="text" name="username" value="<?= htmlspecialchars($old_username ?? '', ENT_QUOTES, 'UTF-8') ?>" autocomplete="username" required autofocus></label><label>Password<input type="password" name="password" autocomplete="current-password" required></label><button class="button button-primary button-wide" type="submit">Sign in</button></form></div>
</section>
<?php require APP_DIR . 'views/partials/footer.php'; ?>
