<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($page_title ?? 'Inventory Manager', ENT_QUOTES, 'UTF-8') ?> | Product Manager</title>
    <link rel="stylesheet" href="<?= htmlspecialchars(base_url('assets/app.css'), ENT_QUOTES, 'UTF-8') ?>">
</head>
<body>
<header class="site-header">
    <a class="brand" href="<?= htmlspecialchars(site_url('products'), ENT_QUOTES, 'UTF-8') ?>"><span class="brand-mark">PM</span><span><strong>Product Manager</strong><small>Inventory system</small></span></a>
    <?php if (!empty($current_user)): ?>
        <div class="account"><span>Signed in as <strong><?= htmlspecialchars($current_user, ENT_QUOTES, 'UTF-8') ?></strong></span><form method="post" action="<?= htmlspecialchars(site_url('logout'), ENT_QUOTES, 'UTF-8') ?>"><?php csrf_field(); ?><button class="button button-ghost" type="submit">Sign out</button></form></div>
    <?php endif; ?>
</header>
<main class="page-shell">
    <?php if (!empty($flash_success)): ?><div class="alert alert-success" role="status"><?= htmlspecialchars($flash_success, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if (!empty($flash_error)): ?><div class="alert alert-error" role="alert"><?= htmlspecialchars($flash_error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
