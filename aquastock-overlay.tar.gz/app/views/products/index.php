<?php require APP_DIR . 'views/partials/header.php'; ?>
<section class="page-heading"><div><span class="eyebrow">Inventory records</span><h1>Products</h1><p>View and manage product details, prices, and stock quantities.</p></div><a class="button button-primary" href="<?= htmlspecialchars(site_url('products/create'), ENT_QUOTES, 'UTF-8') ?>">+ Add product</a></section>
<section class="card table-card">
<?php if (empty($products)): ?>
    <div class="empty-state"><div class="empty-icon">≈</div><h2>No products found</h2><p>Add your first product record to the inventory.</p><a class="button button-primary" href="<?= htmlspecialchars(site_url('products/create'), ENT_QUOTES, 'UTF-8') ?>">Add first product</a></div>
<?php else: ?>
    <div class="table-wrap"><table><thead><tr><th>Product</th><th>Description</th><th>Price</th><th>Quantity</th><th>Created</th><th class="actions-cell">Actions</th></tr></thead><tbody>
    <?php foreach ($products as $product): ?><tr><td><strong><?= htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8') ?></strong><small class="record-id">#<?= (int) $product['id'] ?></small></td><td class="description-cell"><?= htmlspecialchars($product['description'] ?: '—', ENT_QUOTES, 'UTF-8') ?></td><td class="numeric">₱<?= number_format((float) $product['price'], 2) ?></td><td><span class="quantity-badge"><?= number_format((int) $product['quantity']) ?></span></td><td><?= htmlspecialchars(date('M j, Y', strtotime($product['created_at'])), ENT_QUOTES, 'UTF-8') ?></td><td class="actions-cell"><a class="text-link" href="<?= htmlspecialchars(site_url('products/edit/' . (int) $product['id']), ENT_QUOTES, 'UTF-8') ?>">Edit</a><a class="text-link danger" href="<?= htmlspecialchars(site_url('products/delete/' . (int) $product['id']), ENT_QUOTES, 'UTF-8') ?>">Delete</a></td></tr><?php endforeach; ?>
    </tbody></table></div>
<?php endif; ?>
</section>
<?php require APP_DIR . 'views/partials/footer.php'; ?>
