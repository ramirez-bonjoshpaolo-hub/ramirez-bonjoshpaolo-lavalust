CREATE TABLE IF NOT EXISTS products (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_name VARCHAR(100) NOT NULL,
    description TEXT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    quantity INT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_products_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO products (product_name, description, price, quantity) VALUES
('Wireless Mouse', 'Compact wireless mouse with silent-click buttons.', 849.00, 18),
('USB-C Hub', 'Six-port hub with HDMI, USB-A, and card reader.', 1599.50, 9),
('Laptop Stand', 'Adjustable aluminum stand for notebooks up to 17 inches.', 1250.00, 12);
